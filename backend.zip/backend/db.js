const mysql = require("mysql2/promise");

// Create a MySQL connection pool using environment variables
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Helper: Insert customer with duplicate handling
// Usage: const { insertCustomer } = require('./db');
//        const result = await insertCustomer(member_id, name, mobile, latitude, longitude);
//        if (result.duplicate) { ... }
async function insertCustomer(member_id, name, mobile, latitude, longitude) {
  try {
    await pool.promise().query(
      'INSERT INTO customers (member_id, name, mobile, latitude, longitude) VALUES (?, ?, ?, ?, ?)',
      [member_id, name, mobile, latitude || null, longitude || null]
    );
    return { success: true };
  } catch (err) {
    if (err && err.code === 'ER_DUP_ENTRY') {
      // Logical duplicate error, do not expose SQL error
      return { duplicate: true };
    }
    // Unexpected error, do not expose SQL error
    return { error: true };
  }
}

module.exports = pool;
module.exports.insertCustomer = insertCustomer;
