-- Users table for member registration
CREATE TABLE IF NOT EXISTS users (
	id INT AUTO_INCREMENT PRIMARY KEY,
	fullName VARCHAR(100),
	email VARCHAR(100),
	address VARCHAR(255),
	password VARCHAR(255),
	mobile VARCHAR(15) NOT NULL UNIQUE,
	role ENUM('member', 'admin') NOT NULL DEFAULT 'member',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
