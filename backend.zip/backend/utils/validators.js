// Customer registration validator
function validateCustomerRegistration({ name, mobile, latitude, longitude }) {
  // Name: required, min 2 chars
  if (typeof name !== 'string' || name.trim().length < 2) {
    return { valid: false, message: 'Name must be at least 2 characters' };
  }
  // Mobile: required, numeric, length 10-15
  if (typeof mobile !== 'string' || !/^[0-9]{10,15}$/.test(mobile.trim())) {
    return { valid: false, message: 'Mobile number must be 10 to 15 digits' };
  }
  // Latitude/Longitude: optional, but if present must be valid decimals
  if (latitude !== undefined && latitude !== null) {
    if (typeof latitude !== 'number' || !isFinite(latitude)) {
      return { valid: false, message: 'Latitude must be a valid decimal number' };
    }
  }
  if (longitude !== undefined && longitude !== null) {
    if (typeof longitude !== 'number' || !isFinite(longitude)) {
      return { valid: false, message: 'Longitude must be a valid decimal number' };
    }
  }
  return { valid: true };
}
// Validation helper functions

function isValidMobile(mobile) {
  // Accept only string of exactly 10 digits, no spaces, no non-numeric chars
  return typeof mobile === 'string' && /^[0-9]{10}$/.test(mobile.trim());
}

function isValidOtp(otp) {
  return typeof otp === 'string' && /^\d{6}$/.test(otp);
}

function isValidLatLng(lat, lng) {
  return typeof lat === 'number' && typeof lng === 'number' && lat !== null && lng !== null;
}

function isNonEmptyString(value) {
  // Accept any string with at least 1 non-space character
  return typeof value === 'string' && value.trim().length > 0;
}

module.exports = {
  isValidMobile,
  isValidOtp,
  isValidLatLng,
  isNonEmptyString,
  validateCustomerRegistration,
};
