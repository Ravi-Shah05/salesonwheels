require('dotenv').config();
const pool = require('../db');

async function flush() {
  console.log('Flushing database:', process.env.DB_NAME);
  try {
    await pool.promise().query('SET FOREIGN_KEY_CHECKS = 0');
    const tables = ['otp_verifications', 'customers', 'users'];
    for (const t of tables) {
      try {
        await pool.promise().query(`TRUNCATE TABLE \`${t}\``);
        console.log(`Truncated: ${t}`);
      } catch (err) {
        console.warn(`Skip ${t}:`, err.code || err.message);
      }
    }
    await pool.promise().query('SET FOREIGN_KEY_CHECKS = 1');
    console.log('Done.');
    process.exit(0);
  } catch (err) {
    console.error('Flush failed:', err);
    process.exit(1);
  }
}

flush();
