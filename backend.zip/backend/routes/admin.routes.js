const express = require('express');
const router = express.Router();
const { getAllMembers, getAllCustomers, getAdminDashboard } = require('../controllers/admin.controller');
const auth = require('../middleware/auth.middleware');
const admin = require('../middleware/admin.middleware');

// Protect all admin routes
router.use(auth, admin);

router.get('/dashboard', getAdminDashboard);
router.get('/members', getAllMembers);
router.get('/customers', getAllCustomers);

module.exports = router;
