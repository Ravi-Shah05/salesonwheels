const express = require('express');
const authMiddleware = require('../middleware/auth.middleware');
const pool = require('../db');
const router = express.Router();

// GET /member/profile (protected)
router.get('/member/profile', authMiddleware, async (req, res) => {
  try {
    const member_id = req.user && req.user.id;
    if (!member_id) return res.status(401).json({ success: false, message: 'Unauthorized' });
    const [[user]] = await pool.promise().query(
      'SELECT id, fullName AS name, email, address, mobile FROM users WHERE id = ? AND role = "member"',
      [member_id]
    );
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, data: user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
});

module.exports = router;
