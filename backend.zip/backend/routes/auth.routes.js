
const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');

// POST /login (member password login)
router.post('/login', authController.loginMember);
// POST /send-otp
router.post('/send-otp', authController.sendOtp);
// POST /verify-otp
router.post('/verify-otp', authController.verifyOtp);
// GET /peek-otp (development helper to fetch latest OTP for a mobile)
router.get('/peek-otp', authController.peekOtp);

module.exports = router;
