
const express = require('express');
const authMiddleware = require('../middleware/auth.middleware');
const customerController = require('../controllers/customer.controller');
const router = express.Router();

// Customer OTP routes (protected)
router.post('/customer/send-otp', authMiddleware, customerController.sendCustomerOtp);
router.post('/customer/verify-otp', authMiddleware, customerController.verifyCustomerOtpAndCreate);
// Development helper: fetch latest OTP for a customer mobile
router.get('/customer/peek-otp', authMiddleware, customerController.peekCustomerOtp);

// GET /customers (protected)
router.get('/customers', authMiddleware, customerController.getMyCustomers);

// POST /customer (protected)
router.post('/customer', authMiddleware, customerController.addCustomer);

module.exports = router;
