const express = require('express');
const authMiddleware = require('../middleware/auth.middleware');
const dashboardController = require('../controllers/dashboard.controller');
const router = express.Router();

// GET /dashboard (protected)
router.get('/dashboard', authMiddleware, dashboardController.getMemberDashboard);

module.exports = router;
