// Verify customer OTP and create customer record
exports.verifyCustomerOtpAndCreate = async (req, res) => {
  try {
    const member_id = req.user && req.user.id;
    if (!member_id) return res.status(401).json({ success: false, message: 'Unauthorized' });

    let { name, mobile, otp, latitude, longitude } = req.body;
    if (typeof mobile === 'number') mobile = String(mobile);
    if (!validators.isNonEmptyString(name)) {
      return res.status(400).json({ success: false, message: 'Invalid name' });
    }
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    if (!validators.isValidOtp(otp)) {
      return res.status(400).json({ success: false, message: 'Invalid OTP. Must be a 6 digit number.' });
    }
    if (!validators.isValidLatLng(latitude, longitude)) {
      return res.status(400).json({ success: false, message: 'Invalid latitude or longitude' });
    }
    const pool = require('../db');
    // Find OTP for this mobile, purpose 'customer', not expired, not verified
    const [rows] = await pool.promise().query(
      `SELECT * FROM otp_verifications WHERE mobile = ? AND otp = ? AND purpose = 'customer' AND expires_at > NOW() AND verified = 0 ORDER BY expires_at DESC LIMIT 1`,
      [mobile, otp]
    );
    if (!rows.length) {
      return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });
    }
    const otpRow = rows[0];
    // Mark OTP as verified
    await pool.promise().query(
      'UPDATE otp_verifications SET verified = 1 WHERE id = ?',
      [otpRow.id]
    );
    // Insert customer
    await pool.promise().query(
      'INSERT INTO customers (member_id, name, mobile, address, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)',
      [member_id, name, mobile, req.body.address || '', latitude, longitude]
    );
    res.json({ success: true, message: 'Customer created successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
// Send OTP to customer mobile (for customer verification, not member login)
exports.sendCustomerOtp = async (req, res) => {
  try {
    let { mobile } = req.body;
    // Always treat as string for validation and DB
    if (typeof mobile === 'number') mobile = String(mobile);
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    const pool = require('../db');
    // Check for unexpired OTP created within last 60 seconds for this mobile and purpose 'customer'
    const [existingOtps] = await pool.promise().query(
      `SELECT * FROM otp_verifications WHERE mobile = ? AND purpose = 'customer' AND expires_at > NOW() ORDER BY id DESC LIMIT 1`,
      [mobile]
    );
    if (existingOtps.length > 0) {
      const lastOtp = existingOtps[0];
      const createdTime = new Date(lastOtp.expires_at.getTime() - 5 * 60 * 1000); // expires_at - 5 min
      if ((Date.now() - createdTime.getTime()) < 60 * 1000) {
        return res.status(429).json({ success: false, message: 'Please wait before requesting a new OTP' });
      }
    }
    // Generate 6-digit OTP (fixed for temporary live use)
    const otp = process.env.FIXED_OTP || "131005";
    const expires_at = new Date(Date.now() + 5 * 60 * 1000); // 5 min from now
    await pool.promise().query(
      'INSERT INTO otp_verifications (mobile, otp, expires_at, purpose) VALUES (?, ?, ?, ?)',
      [mobile, otp, expires_at, 'customer']
    );
    // Development mode: return OTP to display in popup
    res.json({ success: true, data: { otp }, message: 'OTP generated for customer (development)' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};

// Peek latest unexpired OTP for a given customer mobile (development helper)
exports.peekCustomerOtp = async (req, res) => {
  try {
    let { mobile } = req.query;
    if (typeof mobile === 'number') mobile = String(mobile);
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    const [rows] = await pool.promise().query(
      `SELECT otp FROM otp_verifications WHERE mobile = ? AND purpose = 'customer' AND expires_at > NOW() ORDER BY id DESC LIMIT 1`,
      [mobile]
    );
    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'No active OTP found' });
    }
    res.json({ success: true, data: { otp: rows[0].otp } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
const validators = require('../utils/validators');
// Get customers for the authenticated member (only their own)
exports.getMyCustomers = async (req, res) => {
  try {
    const member_id = req.user && req.user.id;
    if (!member_id) return res.status(401).json({ success: false, message: 'Unauthorized' });

    // Only fetch customers for this member, return only required fields
    const [rows] = await pool.promise().query(
      `SELECT id, name, mobile, address, latitude, longitude, created_at FROM customers WHERE member_id = ? ORDER BY created_at DESC`,
      [member_id]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
const pool = require('../db');

// Add customer controller (updated for new schema and rules)
exports.addCustomer = async (req, res) => {
  try {
    const member_id = req.user && req.user.id;
    if (!member_id) return res.status(401).json({ success: false, message: 'Unauthorized' });


    let { name, mobile, latitude, longitude } = req.body;

    // Validation: name (required, non-empty string)
    if (!validators.isNonEmptyString(name)) {
      return res.status(400).json({ success: false, message: 'Invalid name' });
    }
    // Validation: mobile (required, valid length)
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    // Validation: latitude/longitude (optional, but if present must be valid and in range)
    if (latitude !== undefined && latitude !== null) {
      if (typeof latitude !== 'number' || !isFinite(latitude) || latitude < -90 || latitude > 90) {
        return res.status(400).json({ success: false, message: 'Latitude must be between -90 and 90' });
      }
    }
    if (longitude !== undefined && longitude !== null) {
      if (typeof longitude !== 'number' || !isFinite(longitude) || longitude < -180 || longitude > 180) {
        return res.status(400).json({ success: false, message: 'Longitude must be between -180 and 180' });
      }
    }

    // Check for duplicate (member_id, mobile)
    const [existing] = await pool.promise().query(
      'SELECT id FROM customers WHERE member_id = ? AND mobile = ? LIMIT 1',
      [member_id, mobile]
    );
    if (existing.length > 0) {
      return res.status(409).json({ success: false, message: 'Customer already registered under your account' });
    }


    // Insert into customers table ONLY, use NULL if not provided
    await pool.promise().query(
      'INSERT INTO customers (member_id, name, mobile, latitude, longitude) VALUES (?, ?, ?, ?, ?)',
      [
        member_id,
        name,
        mobile,
        (latitude !== undefined && latitude !== null) ? latitude : null,
        (longitude !== undefined && longitude !== null) ? longitude : null
      ]
    );

    res.json({ success: true, message: 'Customer added successfully' });
  } catch (err) {
    // Duplicate entry error (should not occur due to pre-check, but handle just in case)
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ success: false, message: 'Customer already registered under your account' });
    }
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
