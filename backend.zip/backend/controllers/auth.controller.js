// Member login with mobile and password
exports.loginMember = async (req, res) => {
  try {
    let { mobile, password } = req.body;
    if (typeof mobile === 'number') mobile = String(mobile);
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    if (!password || typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }
    // Find user
    const [userRows] = await pool.promise().query(
      'SELECT * FROM users WHERE mobile = ?',
      [mobile]
    );
    if (!userRows.length) {
      return res.status(400).json({ success: false, message: 'User not found.' });
    }
    const user = userRows[0];
    if (user.password !== password) {
      return res.status(400).json({ success: false, message: 'Incorrect password.' });
    }
    // Generate JWT
    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '24h' }
    );
    res.json({ success: true, data: { token } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
const validators = require('../utils/validators');
const pool = require('../db');
const jwt = require('jsonwebtoken');

// Helper to generate 6-digit OTP (fixed for temporary live use)
function generateOtp() {
  // Always use the fixed OTP while DLT is pending; override via FIXED_OTP
  return (process.env.FIXED_OTP || "131005");
}

// sendOtp: Accepts mobile, stores OTP with expiry
exports.sendOtp = async (req, res) => {
  try {
    let { mobile } = req.body;
    // Always treat as string for validation and DB
    if (typeof mobile === 'number') mobile = String(mobile);
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    // Check if mobile already exists in users table
    const [userRows] = await pool.promise().query(
      'SELECT id FROM users WHERE mobile = ?',
      [mobile]
    );
    if (userRows.length > 0) {
      return res.status(400).json({ success: false, message: 'Mobile number already registered.' });
    }
    // Check for unexpired OTP created within last 60 seconds
    const [existingOtps] = await pool.promise().query(
      `SELECT * FROM otp_verifications WHERE mobile = ? AND expires_at > NOW() ORDER BY id DESC LIMIT 1`,
      [mobile]
    );
    if (existingOtps.length > 0) {
      const lastOtp = existingOtps[0];
      const createdTime = new Date(lastOtp.expires_at.getTime() - 5 * 60 * 1000); // expires_at - 5 min
      if ((Date.now() - createdTime.getTime()) < 60 * 1000) {
        return res.status(429).json({ success: false, message: 'Please wait before requesting a new OTP' });
      }
    }
    const otp = generateOtp();
    const expires_at = new Date(Date.now() + 5 * 60 * 1000); // 5 min from now
    await pool.promise().query(
      'INSERT INTO otp_verifications (mobile, otp, expires_at) VALUES (?, ?, ?)',
      [mobile, otp, expires_at]
    );
    // Development mode: DLT/SMS unavailable, return OTP in response for popup display
    res.json({ success: true, data: { otp }, message: 'OTP generated (development)' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};

// verifyOtp: Accepts mobile, otp; validates, creates user if needed, returns JWT
exports.verifyOtp = async (req, res) => {
  try {
    let { mobile, otp, fullName, email, address, password } = req.body;
    if (typeof mobile === 'number') mobile = String(mobile);
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    if (!validators.isValidOtp(otp)) {
      return res.status(400).json({ success: false, message: 'Invalid OTP. Must be a 6 digit number.' });
    }
    // Check OTP
    const [rows] = await pool.promise().query(
      'SELECT * FROM otp_verifications WHERE mobile = ? AND otp = ? AND expires_at > NOW() ORDER BY expires_at DESC LIMIT 1',
      [mobile, otp]
    );
    if (!rows.length) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });
    const otpRow = rows[0];
    if (otpRow.verified) {
      return res.status(400).json({ success: false, message: 'OTP has already been used' });
    }
    // Mark OTP as verified
    await pool.promise().query(
      'UPDATE otp_verifications SET verified = 1 WHERE id = ?',
      [otpRow.id]
    );
    // Check if user exists
    let [userRows] = await pool.promise().query(
      'SELECT * FROM users WHERE mobile = ?',
      [mobile]
    );
    let user;
    if (!userRows.length) {
      // Validate additional fields for new user
      if (!fullName || typeof fullName !== 'string' || fullName.length < 2) {
        return res.status(400).json({ success: false, message: 'Full name is required.' });
      }
      if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
        return res.status(400).json({ success: false, message: 'Valid email is required.' });
      }
      if (!address || typeof address !== 'string' || address.length < 3) {
        return res.status(400).json({ success: false, message: 'Address is required.' });
      }
      if (!password || typeof password !== 'string' || password.length < 6) {
        return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
      }
      // Create user with all fields
      const [result] = await pool.promise().query(
        "INSERT INTO users (fullName, email, address, password, mobile, role) VALUES (?, ?, ?, ?, ?, 'member')",
        [fullName, email, address, password, mobile]
      );
      user = { id: result.insertId, fullName, email, address, password, mobile, role: 'member' };
    } else {
      user = userRows[0];
    }

    // Destroy all existing sessions for this user (single login enforcement)
    // const { sessionStore } = require('../session');
    // Find all sessions, parse, and destroy those with this user id
    // const allSessions = await sessionStore.sessionModel.findAll();
    // for (const sess of allSessions) {
    //   try {
    //     const data = JSON.parse(sess.data);
    //     if (data && data.user && data.user.id === user.id) {
    //       await sessionStore.destroy(sess.sid);
    //     }
    //   } catch (e) {}
    // }

    // Generate JWT
    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '24h' }
    );
    res.json({ success: true, data: { token } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};

// peekOtp: Development helper to fetch latest unexpired OTP for a mobile
exports.peekOtp = async (req, res) => {
  try {
    let { mobile } = req.query;
    if (typeof mobile === 'number') mobile = String(mobile);
    if (!validators.isValidMobile(mobile)) {
      return res.status(400).json({ success: false, message: 'Invalid mobile number. Must be a 10 digit number.' });
    }
    const [rows] = await pool.promise().query(
      `SELECT otp FROM otp_verifications WHERE mobile = ? AND expires_at > NOW() ORDER BY id DESC LIMIT 1`,
      [mobile]
    );
    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'No active OTP found' });
    }
    res.json({ success: true, data: { otp: rows[0].otp } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
