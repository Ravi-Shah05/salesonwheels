const pool = require('../db');
const jwt = require('jsonwebtoken');

// Admin login: Accepts email and password, returns JWT if valid
exports.adminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }
    // Fetch admin user
    const [rows] = await pool.promise().query(
      "SELECT * FROM users WHERE email = ? AND role = 'admin' LIMIT 1",
      [email]
    );
    if (!rows.length) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }
    const user = rows[0];
    // Compare password (plain text for now)
    if (user.password !== password) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }
    // Generate JWT
    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '24h' }
    );
    return res.json({ success: true, data: { token } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
