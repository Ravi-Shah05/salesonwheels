const pool = require('../db');

// Get dashboard stats for a member
exports.getMemberDashboard = async (req, res) => {
  try {
    const member_id = req.user && req.user.id;
    if (!member_id) return res.status(401).json({ error: 'Unauthorized' });

    // Count total customers
    const [[{ total_customers }]] = await pool.promise().query(
      'SELECT COUNT(*) AS total_customers FROM customers WHERE member_id = ?',
      [member_id]
    );

    // Count customers added today
    const [[{ today_customers }]] = await pool.promise().query(
      `SELECT COUNT(*) AS today_customers FROM customers WHERE member_id = ? AND DATE(created_at) = CURDATE()`,
      [member_id]
    );

    // Count customers added this week (from Monday)
    const [[{ week_customers }]] = await pool.promise().query(
      `SELECT COUNT(*) AS week_customers FROM customers WHERE member_id = ? AND YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)`,
      [member_id]
    );

    // Count customers added this month
    const [[{ month_customers }]] = await pool.promise().query(
      `SELECT COUNT(*) AS month_customers FROM customers WHERE member_id = ? AND YEAR(created_at) = YEAR(CURDATE()) AND MONTH(created_at) = MONTH(CURDATE())`,
      [member_id]
    );

    // Registrations over time (last 30 days)
    const [registrationsRows] = await pool.promise().query(
      `SELECT DATE(created_at) as date, COUNT(*) as count FROM customers WHERE member_id = ? AND created_at >= DATE_SUB(CURDATE(), INTERVAL 29 DAY) GROUP BY DATE(created_at) ORDER BY date ASC`,
      [member_id]
    );

    // Fill missing days with 0, format as dd-mm-yyyy
    const registrations_over_time = [];
    const today = new Date();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const dateStr = `${yyyy}-${mm}-${dd}`;
      // Always compare as string (MySQL may return Date object or string)
      const found = registrationsRows.find(r => {
        let sqlDate = r.date;
        if (sqlDate instanceof Date) {
          sqlDate = sqlDate.toISOString().slice(0, 10);
        }
        return sqlDate === dateStr;
      });
      registrations_over_time.push({ date: dateStr, count: found ? found.count : 0 });
    }

    res.json({ total_customers, today_customers, week_customers, month_customers, registrations_over_time });
  } catch (err) {
    res.status(500).json({ error: 'Server error', details: err.message });
  }
};
