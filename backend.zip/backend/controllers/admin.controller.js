// Get admin dashboard stats
exports.getAdminDashboard = async (req, res) => {
  try {
    // Count total members
    const [memberRows] = await pool.promise().query(
      "SELECT COUNT(*) as total_members FROM users WHERE role = 'member'"
    );
    // Count total customers
    const [customerRows] = await pool.promise().query(
      "SELECT COUNT(*) as total_customers FROM customers"
    );
    // Count customers added today
    const [todayRows] = await pool.promise().query(
      "SELECT COUNT(*) as today_customers FROM customers WHERE DATE(created_at) = CURDATE()"
    );
    res.json({
      success: true,
      data: {
        total_members: memberRows[0].total_members,
        total_customers: customerRows[0].total_customers,
        today_customers: todayRows[0].today_customers
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
const pool = require('../db');

// Get all members (users with role = 'member')
exports.getAllMembers = async (req, res) => {
  try {
    const [rows] = await pool.promise().query(
      "SELECT id, name, email, mobile FROM users WHERE role = 'member'"
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};

// Get all customers with member name
exports.getAllCustomers = async (req, res) => {
  try {
    const { startDate, endDate, member_id } = req.query;
    let sql = `SELECT c.*, u.name as member_name, u.mobile as member_mobile
      FROM customers c
      JOIN users u ON c.member_id = u.id`;
    const filters = [];
    const params = [];
    if (startDate) {
      filters.push('DATE(c.created_at) >= ?');
      params.push(startDate);
    }
    if (endDate) {
      filters.push('DATE(c.created_at) <= ?');
      params.push(endDate);
    }
    if (member_id) {
      filters.push('c.member_id = ?');
      params.push(member_id);
    }
    if (filters.length > 0) {
      sql += ' WHERE ' + filters.join(' AND ');
    }
    sql += ' ORDER BY c.created_at DESC';
    const [rows] = await pool.promise().query(sql, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  }
};
