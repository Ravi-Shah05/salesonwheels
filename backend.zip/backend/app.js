require('dotenv').config();

const express = require("express");
const app = express();
app.use(express.json());

// CORS configuration for production
const corsOptions = {
  origin: process.env.CORS_ORIGIN || ['https://salesonwheels.com', 'https://www.salesonwheels.com'],
  credentials: true
};
app.use(require("cors")(corsOptions));

// Import and mount auth routes
const authRoutes = require('./routes/auth.routes');
app.use('/api/auth', authRoutes);

// Import and mount admin auth routes
const adminAuthRoutes = require('./routes/admin.auth.routes');
app.use('/api/admin/auth', adminAuthRoutes);

// Import and mount admin routes
const adminRoutes = require('./routes/admin.routes');
app.use('/api/admin', adminRoutes);

// Import and mount customer routes
const customerRoutes = require('./routes/customer.routes');
app.use('/api/member', customerRoutes);


// Import and mount dashboard routes
const dashboardRoutes = require('./routes/dashboard.routes');
app.use('/api/member', dashboardRoutes);

// Import and mount member profile route
const memberProfileRoutes = require('./routes/member.profile.routes');
app.use('/api', memberProfileRoutes);

app.get("/", (req, res) => {
  res.json({ status: "online", service: "Sales on Wheels API" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
